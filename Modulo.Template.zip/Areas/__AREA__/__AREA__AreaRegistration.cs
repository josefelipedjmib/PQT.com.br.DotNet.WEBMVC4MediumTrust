﻿
using Essenciais.MVC.Areas;

namespace Modulo.__AREA__.Areas.__AREA__
{
    public class __AREA__AreaRegistration : SmartAreaRegistration
    {
        public override string AreaName => "__AREA__";

        protected override string[] GetNamespaces()
        {
            return new[] { "Modulo." + AreaName + ".Areas." + AreaName + ".Controllers" };
        }
    }
}