﻿using Service;
using System.Web.Mvc;
using Essenciais.MVC;
using Essenciais.MVC.ActionFilters;
using Essenciais.MVC.Extensions;
using Essenciais.MVC.Extensions.Mappers;
using Essenciais.MVC.Models;
using Infrastructure;
using Auxiliar.Helper;
using Service.Mail;
using System.Threading.Tasks;
using System.Collections.Generic;
using System;
using System.Linq;

namespace Modulo.__AREA__.Areas.__AREA__.Controllers
{
    [AutorizadorActionFilter]
    // Pode tirar o AutorizadorActionFilter para permitir acesso ANONIMOUS a toda controller
    public class __AREA__Controller : Controller
    {
        // GET: __AREA__/Action
        [AllowAnonymous]
        // Caso use o AutorizadorActionFilter, pode permitir AllowAnonymous em action escolhida
        public ActionResult Index()
        {
            return View();
        }
    }
}